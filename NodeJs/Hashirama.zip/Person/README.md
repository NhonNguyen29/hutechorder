# Tên nhóm: Hashirama

# Tên thành viên:

- 2011065272 Nguyễn Văn Nghĩa
- 2011780577 Nguyễn Tấn Hùng
- 2011064288 Nguyễn Hoàng Phúc
- 2011060729 Nguyễn Xuân Nhân
- 2011060756 Nguyễn Thành Nhơn
