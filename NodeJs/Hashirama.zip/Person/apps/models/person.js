class Person {
  _id;
  Age;
  Name;
  Office;
  Position;
  StartDate;
}

module.exports = Person;
