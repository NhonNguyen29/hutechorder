let { ObjectId } = require('mongodb');
const config = require('../../configs/setting.json');

class PersonService {
  client;
  database;
  collection;
  person = require('./../models/person');
  connection = require('./../database/database');

  constructor() {
    this.client = this.connection.getMongoClient();
    this.database = this.client.db(config.mongodb.database);
    this.collection = this.database.collection('person');
  }
  async getTotalPersonCount() {
    const count = await this.collection.countDocuments();
    return count;
  }
  async findAll(page = 1, limit = 10) {
    const skip = (page - 1) * limit;
    const persons = await this.collection
      .find()
      .skip(skip)
      .limit(limit)
      .toArray();
    return persons;
  }
  async findById(id) {
    const person = await this.collection.findOne({ _id: new ObjectId(id) });
    return person;
  }
  async create(person) {
    const result = await this.collection.insertOne(person);
    return result;
  }

  async update(id, person) {
    const result = await this.collection.updateOne(
      { _id: new ObjectId(id) },
      { $set: person }
    );
    return result;
  }

  async delete(id) {
    const result = await this.collection.deleteOne({ _id: new ObjectId(id) });
    return result;
  }
}

module.exports = PersonService;
