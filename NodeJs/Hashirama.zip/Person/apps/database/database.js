const config = require('../../configs/setting.json');

class DatabaseConnection {
  url;
  user;
  pass;
  static getMongoClient() {
    this.user = config.mongodb.username;
    this.pass = config.mongodb.password;
    this.url = `mongodb+srv://${this.user}:${this.pass}@cluster0.homac7h.mongodb.net/?retryWrites=true&w=majority&serverSelectionTimeoutMS=5000&connectTimeoutMS=10000`;
    const { MongoClient } = require('mongodb');
    const client = new MongoClient(this.url);
    return client;
  }
}

module.exports = DatabaseConnection;
