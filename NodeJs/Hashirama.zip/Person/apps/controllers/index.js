const express = require('express');
const router = express.Router();

router.use('/api/v1/person', require(__dirname + '/person-controller'));

router.get('/add', function (req, res) {
  res.render('../views/add.ejs');
});

router.get('/', function (req, res) {
  res.render('../views/index.ejs');
});

router.get('/edit/:id', function (req, res) {
  res.render('../views/edit.ejs');
});

module.exports = router;
