const express = require('express');
const { ObjectId } = require('mongodb');
const Person = require('./../models/person');
const PersonService = require('./../services/person-service');

const router = express.Router();

router.get('/', async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const personService = new PersonService();
  const persons = await personService.findAll(page, limit);
  let totalRecords = await personService.getTotalPersonCount();
  res.json({
    data: persons,
    recordsTotal: totalRecords,
    recordsFiltered: totalRecords,
  });
});

router.get('/:id', async (req, res) => {
  const id = req.params.id;
  const personService = new PersonService();
  const person = await personService.findById(id);
  res.json(person);
});

router.post('/', async (req, res) => {
  const person = new Person();
  person._id = new ObjectId();
  console.log(req.body);
  person.Name = req.body.name;
  person.Age = parseInt(req.body.age);
  person.Office = req.body.office;
  person.Position = req.body.position;
  person.StartDate = req.body.startDate;
  const personService = new PersonService();
  const result = await personService.create(person);
  res.json(result);
});

router.post('/:id', async (req, res) => {
  const person = new Person();
  const id = req.params.id;
  person.Name = req.body.name;
  person.Age = parseInt(req.body.age);
  person.Office = req.body.office;
  person.Position = req.body.position;
  person.StartDate = req.body.startDate;
  delete person._id;
  const personService = new PersonService();
  const result = await personService.update(id, person);
  res.json(result);
});

router.delete('/:id', async (req, res) => {
  const id = req.params.id;
  const personService = new PersonService();
  const result = await personService.delete(id);
  res.json(result);
});

module.exports = router;
